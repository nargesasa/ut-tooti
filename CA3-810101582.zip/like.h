void like(char* order_of_user);
void search_node_for_like(char* username_entered_by_user_for_like,int* post_id);