void signup(char* order_of_user);
sn_user* make_new_node_for_sn_user(char*username_signup,char*password_signup);