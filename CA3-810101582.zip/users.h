void info(char* username_entered_by_user_for_login,char*password_entered_by_user_for_login);
int find_user(char* order_of_user);